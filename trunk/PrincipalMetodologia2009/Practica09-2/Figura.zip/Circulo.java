public class Circulo extends Figura
{
    public Circulo( double r )
    {
        super( "Circulo" );
        radio = r;
    }

    public double area( )
    {
        return PI * radio * radio;
    }

    private static final double PI = 3.14159265358979323;
    private double radio;
}