public abstract class Figura
{
    abstract public double area( );

    public Figura( String nombreFigura )
    {
        nombre = nombreFigura;
    }

    final public boolean menorQue( Figura lder )
    {
        return area( ) < lder.area( );
    }

    final public String toString( )
    {
        return nombre + " con area " + area( );
    }

    private String nombre;
}